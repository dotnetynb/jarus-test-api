import { Component, OnInit } from '@angular/core'; 

import {BaseService} from '../../../services/base.service'
import { map } from 'rxjs/operators';

@Component({
  selector: 'app-persons',
  templateUrl: './persons.component.html',
  styleUrls: ['./persons.component.scss']
})
export class PersonsComponent implements OnInit {

  constructor(private baseService: BaseService) { }

  quote:any;
  persons:any;
  insuredPersons:any;

  ngOnInit(): void {
    this.GetQuote();
    this.GetPersons();
  }



  GetQuote(): any {
    return this.baseService.get("quote").subscribe((response) =>{
      if(response){
        this.quote =  response;      }
    });
  }

  GetPersons(): any {
    return this.baseService.get("person").subscribe((response) =>{
      if(response){
        this.persons =  response; 
        this.setPersons(response);
           }
    });
  }


  setPersons(response:any):any{
    this.rowOriginalData = [];
    response.forEach(element => {
      this.rowOriginalData.push({Id :element.id,
      Name:element.name,
      DoB:element.dob.toString("dd/MM/yyyy"),
      Coverage:element.coverage
      });
      this.rowData = this.rowOriginalData;
});
  }


  onNameFilter(searchValue: string): void {  
    this.rowData = this.rowOriginalData.filter(a=>a.Name.startsWith(searchValue));
    if(this.rowData.length ==0)
    {
      this.rowData = null;
    }
  }

  onDoBFilter(searchValue: string): void {  
    this.rowData = this.rowOriginalData.filter(a=>a.DoB.startsWith(searchValue));
  }


  AddInsured(selected: string): void {  
    var selectedInsured =  this.rowOriginalData.find(a=>a.Id.toString()== selected);
    if(this.addedInsured.find(a=>a.Id.toString() == selected))
    {
alert("Person already Insured");
    }
    else
    {
     this.addedInsured.push(selectedInsured);
    }
  }

  columnDefs = [
    { field: 'Name'},
    { field: 'DoB' }
];

 
rowOriginalData = [
    {Id:1, Name: 'Toyota', DoB: '10/11/2021', Coverage:'60%'},
    {Id:2, Name: 'Ford', DoB: '10/11/2021' , Coverage:'80%'},
    { Id:3,Name: 'Porsche', DoB: '10/11/2021', Coverage:'10%' }
];

rowData = this.rowOriginalData;

addedInsured =[];

}
