import { Component, OnInit } from '@angular/core';
import {BaseService} from '../../../services/base.service'
import {Quote} from '../../../models/quote' 

@Component({
  selector: 'app-quote',
  templateUrl: './quote.component.html',
  styleUrls: ['./quote.component.scss']
})
export class QuoteComponent implements OnInit {
   

  constructor(private baseService: BaseService,) { }

  quote:any;
  options :any;

  ngOnInit(): void {
     this.GetQuote();
  }

  GetQuote(): any {
    return this.baseService.get("quote").subscribe((response) =>{
      if(response){
        this.quote =  response;
         this.options = this.quote.premiumOptions;
      }
    });
  }
}
