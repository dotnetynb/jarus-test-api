import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class BaseService {

  endPointURL: string = '';
  constructor(private httpClient: HttpClient) { }

  get(endpoint: any) { 
      this.endPointURL =environment.ROOT_URL+endpoint.toString();     
       var returnObj = this.httpClient.get(this.endPointURL, { headers: this.getHeader() });   
       return returnObj;   
   }
 
   post(endpoint: any, data: any) {    
      this.endPointURL =environment.ROOT_URL+endpoint.toString();    
       return this.httpClient.post(this.endPointURL, data, { headers: this.getHeader() });     
   }

   getHeader(): HttpHeaders {
    let httpHeader = new HttpHeaders();
    httpHeader.append('Content-Type', 'application/json');
    httpHeader.append('Access-Control-Allow-Origin', '*');
    httpHeader.append('Access-Control-Allow-Methods', 'GET, POST, PATCH, PUT, DELETE, OPTIONS');
    httpHeader.append('Access-Control-Allow-Headers', 'Origin, Content-Type, X-Auth-Token')
    return httpHeader;
  }
}
