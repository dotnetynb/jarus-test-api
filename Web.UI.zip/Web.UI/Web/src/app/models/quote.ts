export interface Quote {
    QuoteId: number;
    QuoteNumber: string;
    QuoteStatus: string;
    Applicant: string;
    QuoteDate: string;
    QuoteEffectiveDate: string;
    PremiumOptions: PremiumOption[];
}

export interface PremiumOption {
    name: string;
    value: string;
}
