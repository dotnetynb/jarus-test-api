﻿using Microsoft.Extensions.Caching.Memory;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Web.Models;
using Web.Repository.IRepository;

namespace Web.Repository
{
    public class QuoteRepository : IQuoteRepository
    {
        private readonly MemoryCache memoryCache;
        public QuoteRepository()
        {
            memoryCache = new MemoryCache(new MemoryCacheOptions());
        }
        public Quote GetQuote()
        {
            return new Quote()
            {
                QuoteId = 1,
                QuoteNumber = "Q92348",
                Applicant = "James Feather LLC",
                QuoteDate = DateTime.Parse("07/07/2020"),
                QuoteEffectiveDate = DateTime.Parse("12/07/2020"),
                QuoteStatus = "Pending",
                PremiumOptions = new List<PremiumOption>()
                {
                    new PremiumOption(){Name="Basic",Value="$680.00"},
                    new PremiumOption(){Name="Preferred",Value="$850.00"},
                     new PremiumOption(){Name="Premier",Value="$1050.00"}
                }

            };
        }

        public Task<List<InsuredPerson>> GetAdditionalInsuredForQuote()
        {
            var list = memoryCache.Get("InsuredPersons");

            return Task.FromResult((List<InsuredPerson>)list);
        }

        public Task<bool> AddInsuredPerson(InsuredPerson insuredPerson)
        {
            var list = memoryCache.Get("InsuredPersons");

            if (list != null)
            {
                var insuredPersons = (List<InsuredPerson>)list;

                insuredPersons.Add(insuredPerson);

                memoryCache.Set("InsuredPersons", insuredPersons);

            }
            return Task.FromResult(true);
        }


    }
}
