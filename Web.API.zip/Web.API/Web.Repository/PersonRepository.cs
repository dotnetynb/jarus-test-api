﻿using System;
using System.Collections.Generic;
using System.Text;
using Web.Models;
using Web.Repository.IRepository;

namespace Web.Repository
{
   public class PersonRepository: IPersonRepository
    {

        public List<Person> GetPersons()
        {
            return new List<Person>()
            {

                new Person()
                {
                    Id=1,
                    Name="Rajesh",
                    DOB =DateTime.Now.AddDays(-10000)
                    ,Coverage="80%"
                },
                new Person()
                {
                    Id=2,
                    Name="Naveen",
                    DOB =DateTime.Now.AddDays(-10500) ,Coverage="80%"
                },
                new Person()
                {
                    Id=3,
                    Name="Babu",
                    DOB =DateTime.Now.AddDays(-10400) ,Coverage="80%"
                },
                new Person()
                {
                    Id=4,
                    Name="Jarus",
                    DOB =DateTime.Now.AddDays(-10450) ,Coverage="80%"
                }
            };
        }
         
    }
}
