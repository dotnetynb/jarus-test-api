﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Web.Models;

namespace Web.Repository.IRepository
{
    public interface IQuoteRepository
    {
        Quote GetQuote();

        Task<List<InsuredPerson>> GetAdditionalInsuredForQuote();

        Task<bool> AddInsuredPerson(InsuredPerson insuredPerson);
    }
}
