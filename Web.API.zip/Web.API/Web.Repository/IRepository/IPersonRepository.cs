﻿using System;
using System.Collections.Generic;
using System.Text;
using Web.Models;

namespace Web.Repository.IRepository
{
  public  interface IPersonRepository
    {
        List<Person> GetPersons();
    }
}
