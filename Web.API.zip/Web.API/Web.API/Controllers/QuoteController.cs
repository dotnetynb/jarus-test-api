﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Web.Models;
using Web.Services.IService;

namespace Web.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class QuoteController : Controller
    {
        private readonly IQuoteService quoteService;

        public QuoteController(IQuoteService quoteService)
        {
            this.quoteService = quoteService;
        }
        public Quote Quote()
        {
            return quoteService.GetQuote();
        }

        [Route("AddInsuredPerson")]
        public async Task<bool> AddInsuredPerson(InsuredPerson insuredPerson)
        {
            return await quoteService.AddInsuredPerson(insuredPerson);
        }

        [Route("AddInsuredPersonForQuote")]
        public async Task<List<InsuredPerson>> GetAdditionalInsuredForQuote()
        {
            return await quoteService.GetAdditionalInsuredForQuote();
        }
    }
}
