﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Web.Models
{
   public class InsuredPerson
    {

        public int AdditionalInsuredId { get; set; }
        public int QuoteId { get; set; }

        public int PersonId { get; set; }
    }
}
