﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Web.Models
{
    public class Person
    {
        public int Id { get; set; }
        public string Name{ get; set; }
        public DateTime DOB{ get; set; }

        public string Coverage { get; set; }
    }
}
