﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Web.Models
{
    public class Quote
    {
        public int QuoteId { get; set; }

        public string QuoteNumber { get; set; }

        public string QuoteStatus { get; set; }

        public string Applicant { get; set; }

        public DateTime QuoteDate { get; set; }

        public DateTime QuoteEffectiveDate { get; set; }

        public List<PremiumOption> PremiumOptions { get; set; }
    }

    public class PremiumOption
    {
        public string Name { get; set; }
        public string Value { get; set; }
    }


}
