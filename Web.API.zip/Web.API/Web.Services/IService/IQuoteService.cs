﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Web.Models;

namespace Web.Services.IService
{
   public interface IQuoteService
    {
        Quote GetQuote();

        Task<List<InsuredPerson>> GetAdditionalInsuredForQuote();

        Task<bool> AddInsuredPerson(InsuredPerson insuredPerson);
    }
}
