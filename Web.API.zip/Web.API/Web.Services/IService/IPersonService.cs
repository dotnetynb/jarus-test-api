﻿using System;
using System.Collections.Generic;
using System.Text;
using Web.Models;

namespace Web.Services.IService
{
  public  interface IPersonService
    {
        List<Person> GetPersons();
    }
}
