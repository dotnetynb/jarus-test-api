﻿using System;
using System.Collections.Generic;
using System.Text;
using Web.Models;
using Web.Repository;
using Web.Repository.IRepository;
using Web.Services.IService;

namespace Web.Services
{
    public class PersonService : IPersonService
    {
        private readonly IPersonRepository personRepository;
        public PersonService(IPersonRepository personRepository)
        {
            this.personRepository = personRepository;
        }

        public List<Person> GetPersons()
        {
            return personRepository.GetPersons();
        }
    }
}
