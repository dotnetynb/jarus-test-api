﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Web.Models;
using Web.Repository.IRepository;
using Web.Services.IService;

namespace Web.Services
{
   public class QuoteService: IQuoteService
    {
        private IQuoteRepository quoteRepository;
        public QuoteService(IQuoteRepository quoteRepository)
        {
            this.quoteRepository = quoteRepository;
        }

        public async Task<bool> AddInsuredPerson(InsuredPerson insuredPerson)
        {
            return await quoteRepository.AddInsuredPerson(insuredPerson);
        }

        public async Task<List<InsuredPerson>> GetAdditionalInsuredForQuote()
        {
            return await quoteRepository.GetAdditionalInsuredForQuote();
        }

        public Quote GetQuote()
        {
            return quoteRepository.GetQuote();
        }
    }
}
